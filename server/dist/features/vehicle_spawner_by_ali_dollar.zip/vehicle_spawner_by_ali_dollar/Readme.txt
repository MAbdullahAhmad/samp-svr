Vehicle Spawner By ::Ali Dollar::
This is the simple Vehicle Spawner With Dialog + mSelection.
copy VehicleSpawner.amx in your Filterscipt Folder, and Copy VehicleSpawner Folder to your scriptfiles Folder.
and add VehicleSpawner in your Server.cfg file.
please Don't re-release this Script any where without my permission.
Enjoy!